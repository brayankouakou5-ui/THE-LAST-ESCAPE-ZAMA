import * as THREE from 'three';
import './style.css';
const scene=new THREE.Scene();scene.background=new THREE.Color(0x171d22);scene.fog=new THREE.Fog(0x171d22,22,75);
const camera=new THREE.PerspectiveCamera(62,innerWidth/innerHeight,.1,120);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;document.querySelector('#game').appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xa9b9c5,0x30302b,2));const sun=new THREE.DirectionalLight(0xffd9a0,2);sun.position.set(-12,22,8);sun.castShadow=true;scene.add(sun);
const material=c=>new THREE.MeshStandardMaterial({color:c,roughness:.9});
function box(w,h,d,x,y,z,m){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);return o}
const concrete=material(0x666b6b),dark=material(0x252b2e),floor=material(0x454a48),gold=material(0xc49a55),uniform=material(0x34434a),skin=material(0x8a573b);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),floor);ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
box(48,8,1,-.5,4,-19,concrete);box(1,8,40,-24,4,0,concrete);box(1,8,40,23,4,0,concrete);box(48,8,1,-.5,4,20,concrete);
for(let x=-20;x<=20;x+=8){box(2.2,10,2.2,x,5,-19,dark);box(2.5,.3,2.5,x,10.1,-19,gold)}
box(8,3,4,-9,1.5,-11,dark);box(7,3.5,4,10,1.75,-10,concrete);box(3.2,4.8,.5,0,2.4,-18.3,dark);
for(let x=-1.2;x<=1.2;x+=.4)box(.07,4.5,.08,x,2.4,-18,gold);
for(const x of [-20,20]){const pole=new THREE.Mesh(new THREE.CylinderGeometry(.12,.16,7,8),dark);pole.position.set(x,3.5,-15);scene.add(pole);const l=new THREE.PointLight(0xffd59a,18,24);l.position.set(x,7,-15);scene.add(l)}
const player=new THREE.Group();scene.add(player);const body=new THREE.Mesh(new THREE.CapsuleGeometry(.43,.8,4,8),uniform);body.position.y=1.05;body.castShadow=true;player.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.29,16,12),skin);head.position.y=1.82;player.add(head);const hair=new THREE.Mesh(new THREE.SphereGeometry(.3,16,8,0,Math.PI*2,0,Math.PI/2),dark);hair.position.y=1.94;player.add(hair);
for(const s of [-1,1]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.55,3,7),uniform);arm.position.set(s*.52,1.12,0);player.add(arm);const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.16,.55,3,7),dark);leg.position.set(s*.2,.38,0);player.add(leg)}
player.position.set(0,0,9);
let yaw=0,mx=0,my=0,running=false,crouched=false,started=false,joyId=null,rect=null,lookId=null,lastX=0;
const joy=document.querySelector('#joystick'),stick=document.querySelector('#stick');
function joyMove(e){if(joyId!==e.pointerId)return;const dx=e.clientX-(rect.left+rect.width/2),dy=e.clientY-(rect.top+rect.height/2),max=rect.width*.34,len=Math.hypot(dx,dy),scale=Math.min(1,max/(len||1)),x=dx*scale,y=dy*scale;stick.style.transform=`translate(${x}px,${y}px)`;mx=x/max;my=-y/max}
joy.addEventListener('pointerdown',e=>{joyId=e.pointerId;rect=joy.getBoundingClientRect();joy.setPointerCapture(e.pointerId);joyMove(e)});joy.addEventListener('pointermove',joyMove);
function joyEnd(e){if(joyId===e.pointerId){joyId=null;mx=my=0;stick.style.transform='translate(0,0)'}}joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
renderer.domElement.addEventListener('pointerdown',e=>{if(e.clientX>innerWidth*.42){lookId=e.pointerId;lastX=e.clientX}});renderer.domElement.addEventListener('pointermove',e=>{if(lookId===e.pointerId){yaw-=(e.clientX-lastX)*.006;lastX=e.clientX}});renderer.domElement.addEventListener('pointerup',()=>lookId=null);renderer.domElement.addEventListener('pointercancel',()=>lookId=null);
const toast=document.querySelector('#toast');function notify(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200)}
document.querySelector('#run').addEventListener('pointerdown',()=>running=true);['pointerup','pointercancel','pointerleave'].forEach(ev=>document.querySelector('#run').addEventListener(ev,()=>running=false));
document.querySelector('#crouch').addEventListener('click',()=>{crouched=!crouched;body.scale.y=crouched?.72:1;notify(crouched?'ZAMA se baisse. Déplacement discret.':'ZAMA se relève.')});
document.querySelector('#interact').addEventListener('click',()=>{if(player.position.distanceTo(new THREE.Vector3(0,0,-15))<6){document.querySelector('#objective').textContent='Porte repérée : trouve un moyen de progresser.';notify('La porte est verrouillée. Observe les alentours.')}else notify('Rien à proximité. Continue à explorer.')});
document.querySelector('#play').addEventListener('click',()=>{started=true;document.querySelector('#start').classList.add('hidden');notify('ZAMA : Je dois comprendre cet endroit.')});
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key==='Shift')running=true});addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key==='Shift')running=false});
const clock=new THREE.Clock(),target=new THREE.Vector3();
function frame(){requestAnimationFrame(frame);const dt=Math.min(clock.getDelta(),.04);if(started){let x=mx+(keys.d?1:0)-(keys.a?1:0),y=my+(keys.w?1:0)-(keys.s?1:0),len=Math.hypot(x,y);if(len>1){x/=len;y/=len}const speed=(crouched?1.1:(running?4:2.2))*dt,forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw)),right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));player.position.addScaledVector(forward,y*speed);player.position.addScaledVector(right,x*speed);player.position.x=THREE.MathUtils.clamp(player.position.x,-21,21);player.position.z=THREE.MathUtils.clamp(player.position.z,-17,18);if(len>.12)player.rotation.y=Math.atan2(-forward.x*y-right.x*x,-forward.z*y-right.z*x)}
target.set(player.position.x,player.position.y+1.35,player.position.z);const desired=new THREE.Vector3(player.position.x+Math.sin(yaw)*7,player.position.y+4.2,player.position.z+Math.cos(yaw)*7);camera.position.lerp(desired,1-Math.pow(.001,dt));camera.lookAt(target);renderer.render(scene,camera)}
frame();addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
