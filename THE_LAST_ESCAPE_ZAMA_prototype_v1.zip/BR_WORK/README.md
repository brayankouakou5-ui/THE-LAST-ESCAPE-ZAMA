# THE LAST ESCAPE : ZAMA — Prototype 3D
Prototype mobile Three.js : cour de prison fictive, caméra troisième personne et commandes tactiles.
- Joystick gauche : déplacement.
- Glisser à droite : orienter la caméra.
- COURIR : maintenir.
- S'ACCROUPIR : activer/désactiver la discrétion.
- INTERAGIR : examiner la porte si ZAMA est proche.
Ce prototype est une base : le personnage est provisoire, les combats et les missions complètes restent à développer.
Compilation : `npm install`, `npm run build`, `npx cap add android`, `npx cap sync android`.
